<?php
include ("db.php");
include("insert.php");

$sql = "INSERT INTO innr (img, name, category, price)
VALUES ('$img','$name','$category','$price')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
  header('location:view.php');
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>