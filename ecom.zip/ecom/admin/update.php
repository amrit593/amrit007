<?php
include("db.php"); 
@$id=$_GET['id'];
// echo $id;

?>

<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>

<body>  

<?php

$sqls="SELECT * FROM innr WHERE id =$id";
$result=mysqli_query($conn,$sqls);
  if(mysqli_num_rows($result)>0){
    $row=mysqli_fetch_assoc($result);
    $name = $row["name1"];
    $category = $row["category"];
    $price = $row["price"];
    $file_name= $row["img"]; 
    echo $name ;
    echo '

    <p><span class="error">* required field</span></p>
    <form method="post" enctype="multipart/form-data" action="">  
     img     <input type="file" name="image" />
      <span class="error">* <?php echo $imgErr;?></span>`
      <br><br>
      Name <input type="text" name="name" value="'.$name.' ">
      <span class="error">* <?php echo $nameErr;?></span>
      <br><br>
      category <input type="text" name="category" value="'.$category.'">
      <span class="error">* <?php echo $categoryErr;?></span>
      <br><br>
      price <input type="text" name="price" value="'.$price.'">
      <span class="error"><?php echo $priceErr;?></span>
      <br><br>
     
      <input type="submit" name="submit" value="Submit">  
    </form>
    ';
  }
// echo $price   ;
// define variables and set to empty values
$imgErr = $categoryErr = $priceErr = "";
$img = $category = $price = $file_name= "";
$name= $nameErr="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["img"])) {
    $imgErr = "img is required";
  } else {
    $img = test_input($_POST["img"]);  
  }
  if (empty($_POST["name1"])) {
    $nameErr = "name is required";
  } else {
    $name = test_input($_POST["name1"]);
  }
  
  if (empty($_POST["category"])) {
    $categoryErr = "category is required";
  } else {
    $category = test_input($_POST["category"]);
  }
    
  if (empty($_POST["price"])) {
    $priceErr = "price is required";
  } else {
    $price = test_input($_POST["price"]);
  }

  
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      @$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"img/".$file_name);
        //  echo "Successfully ";
      }else{
         print_r($errors);
      }
   }

    $sql1="UPDATE innr SET img='$file_name', name='$name', price='$price', category='$category'  WHERE id=$id ";
    print_r($sql1);
    if (mysqli_query($conn,$sql1)) {
        echo "update successfully";
        header ('location: view.php');
    }
    else{
        echo"no";
    }

}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

?>

<?php
echo $img;
echo "<br>";
echo $name;
echo "<br>";
echo $category;
echo "<br>";
echo $price;
echo "<br>";
?>


</body>
</html>
<?php
require('update.php');
  
$update = " UPDATE FROM innr ('img')
VALUES ('$file_name','$name', '$category', '$price')";

if (mysqli_query($conn, $update)) {
  echo "registerd";
}
else
{
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


?>