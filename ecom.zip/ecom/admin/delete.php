<?php
require('db.php');
$id=$_GET['id'];
echo "$id";
// sql to delete a record
$sql = "DELETE FROM innr WHERE id=$id";

if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";
  header('location: view.php');
} else {
  echo "Error deleting record: " . mysqli_error($conn);

}?>

