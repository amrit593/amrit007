<?php
include("db.php"); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>view</title>
</head>
<body>
    <button> <a href="insert.php">New data</a></button>
<?php


if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM innr";
$result = mysqli_query($conn, $sql);
?> <table border="1"> 
    <?php 
if (mysqli_num_rows($result) > 0) {
    ?> <tr>   
  <?php 
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
      ?> 
      <td> <?php echo $row["id"]; ?></td>
      <td> <?php echo $row["name"]; ?></td>
      <td> <?php echo $row["category"]; ?></td>
      <td> <?php echo $row["price"]; ?></td>
      <td> <a href="update.php?id=<?php echo $row["id"];  ?>">update</a></td>
      <td> <a href="delete.php?id=<?php echo $row["id"];  ?>">delete</a></td>
<?php} ?>


  
   </tr>  
  <?php 
//  else {
//   echo "0 results";
} }
?> </table>  
  <?php 
// mysqli_close($conn);
?>
    

    
</body>
</html>