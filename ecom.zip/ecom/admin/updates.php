<?php
// require('update.php');
  
// $update = " UPDATE FROM innr ('img')
// VALUES ('$file_name','$name', '$category', '$price')";

// if (mysqli_query($conn, $update)) {
//   echo "registerd";
// }
// else
// {
//   echo "Error: " . $sql . "<br>" . mysqli_error($conn);
// }


?>